// generated from rosidl_generator_c/resource/idl.h.em
// with input from lab_interfaces:msg/TurtleArray.idl
// generated code does not contain a copyright notice

#ifndef LAB_INTERFACES__MSG__TURTLE_ARRAY_H_
#define LAB_INTERFACES__MSG__TURTLE_ARRAY_H_

#include "lab_interfaces/msg/detail/turtle_array__struct.h"
#include "lab_interfaces/msg/detail/turtle_array__functions.h"
#include "lab_interfaces/msg/detail/turtle_array__type_support.h"

#endif  // LAB_INTERFACES__MSG__TURTLE_ARRAY_H_
