// generated from rosidl_generator_c/resource/idl.h.em
// with input from lab_interfaces:msg/Turtle.idl
// generated code does not contain a copyright notice

#ifndef LAB_INTERFACES__MSG__TURTLE_H_
#define LAB_INTERFACES__MSG__TURTLE_H_

#include "lab_interfaces/msg/detail/turtle__struct.h"
#include "lab_interfaces/msg/detail/turtle__functions.h"
#include "lab_interfaces/msg/detail/turtle__type_support.h"

#endif  // LAB_INTERFACES__MSG__TURTLE_H_
