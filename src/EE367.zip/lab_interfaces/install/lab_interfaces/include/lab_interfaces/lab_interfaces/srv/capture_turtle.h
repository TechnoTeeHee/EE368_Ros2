// generated from rosidl_generator_c/resource/idl.h.em
// with input from lab_interfaces:srv/CaptureTurtle.idl
// generated code does not contain a copyright notice

#ifndef LAB_INTERFACES__SRV__CAPTURE_TURTLE_H_
#define LAB_INTERFACES__SRV__CAPTURE_TURTLE_H_

#include "lab_interfaces/srv/detail/capture_turtle__struct.h"
#include "lab_interfaces/srv/detail/capture_turtle__functions.h"
#include "lab_interfaces/srv/detail/capture_turtle__type_support.h"

#endif  // LAB_INTERFACES__SRV__CAPTURE_TURTLE_H_
