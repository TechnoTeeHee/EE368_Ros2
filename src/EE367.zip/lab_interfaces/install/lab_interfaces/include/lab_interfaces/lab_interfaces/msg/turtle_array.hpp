// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LAB_INTERFACES__MSG__TURTLE_ARRAY_HPP_
#define LAB_INTERFACES__MSG__TURTLE_ARRAY_HPP_

#include "lab_interfaces/msg/detail/turtle_array__struct.hpp"
#include "lab_interfaces/msg/detail/turtle_array__builder.hpp"
#include "lab_interfaces/msg/detail/turtle_array__traits.hpp"

#endif  // LAB_INTERFACES__MSG__TURTLE_ARRAY_HPP_
