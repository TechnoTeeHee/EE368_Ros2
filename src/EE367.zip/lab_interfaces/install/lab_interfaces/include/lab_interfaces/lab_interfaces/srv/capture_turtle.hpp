// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LAB_INTERFACES__SRV__CAPTURE_TURTLE_HPP_
#define LAB_INTERFACES__SRV__CAPTURE_TURTLE_HPP_

#include "lab_interfaces/srv/detail/capture_turtle__struct.hpp"
#include "lab_interfaces/srv/detail/capture_turtle__builder.hpp"
#include "lab_interfaces/srv/detail/capture_turtle__traits.hpp"

#endif  // LAB_INTERFACES__SRV__CAPTURE_TURTLE_HPP_
