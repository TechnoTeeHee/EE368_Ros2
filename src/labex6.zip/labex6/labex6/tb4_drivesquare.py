import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import numpy as np
import math
import time

class TB4DriveSquare(Node):
    def __init__(self):
        super().__init__('tb4_drivesquare')
        self.publisher_ = self.create_publisher(Twist, "cmd_vel", 10)
        self.subscriber_odom_ = self.create_subscription(Odometry, 'odom', self.odom_callback, QoSProfile(depth=10, reliability=QoSReliabilityPolicy.BEST_EFFORT))
        self.linear_speed = 0.3
        self.angular_speed = 0.3
        self.current_pose = None
        self.goal_index = 1
        self.ref_goals_ = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]  # Reference goals for creating a square
        self.ref_goals_ = np.asarray(self.ref_goals_)
        self.counter = 0
        self.rotation_goal = 0
        self.spinning = False  # Flag to indicate if the robot is currently spinning
        self.distance_to_goal = 0

    def odom_callback(self, msg):
        # Callback function to update the current pose based on Odometry messages
        self.current_pose = msg.pose.pose
        # Extract the theta from the quaternion representation
        self.theta = 2 * math.atan2(self.current_pose.orientation.z, self.current_pose.orientation.w)
        # Ensure theta is rempped to a new range (0, 2*pi)
        if self.theta < 0:
            self.theta = abs((abs(self.theta)) - math.pi) + math.pi
        else:
            self.theta = self.theta
        if self.counter == 0:
            # Initialize starting position and angle on the first callback (has to be here since it needs the odometry)
            self.starting_x = self.current_pose.position.x
            self.starting_y = self.current_pose.position.y
            self.starting_theta = self.theta
            self.counter += 1
        self.move()  # Call the move after you get new values

    def move(self):
        # Function to control the robot's movement
        twist = Twist()
        twist.linear.x = 0.0
        if self.spinning:
            # If the robot is spinning and the flag hasn't turned off, keep spinning
            self.turn_turtle_90_degrees()
            return
        if self.has_reached_goal():
            # If the robot has reached the goal, dont move forward and start spinning and preparing for the next goal
            self.spinning = True
            self.get_rotation_goal()
            self.goal_index = (self.goal_index + 1) % 4  # Move to the next goal in the square
            self.counter = 1
            self.has_reached_goal()
        else:
            # If the robot has not reached the goal, set linear velocity slower
            twist.linear.x = self.linear_speed * self.distance_to_goal
        self.publisher_.publish(twist)

    def turn_turtle_90_degrees(self):
        twist = Twist()
        self.get_logger().info(str(self.rotation_goal))
        # Check if the robot has rotated 90 degrees
        if abs(self.theta - self.rotation_goal) < 0.00001:
            twist.angular.z = 0.0
            self.spinning = False
        else:
            # Calculate the angular error and set the angular velocity
            angle_error = self.rotation_goal - self.theta
            angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))
            twist.angular.z = self.angular_speed * angle_error
        self.publisher_.publish(twist)
        
    def get_rotation_goal(self):
        # Function to set the goal angle for a 90-degree turn, only done once it has reached the goal position
        self.rotation_goal = (self.theta + math.radians(90)) % math.radians(360)

    def has_reached_goal(self):
        # Function to check if the robot has reached its goal position
        true_goal = self.rotate_point(self.ref_goals_[self.goal_index])
        # Calculate the absolute goal position in the world frame
        self.goal_position_absolute = np.array([
            true_goal[0] + self.starting_x,
            true_goal[1] + self.starting_y
        ])
        # Calculate the distance to the goal
        self.distance_to_goal = np.linalg.norm(
            np.array([self.current_pose.position.x, self.current_pose.position.y]) - self.goal_position_absolute
        )
        return self.distance_to_goal < 0.01  # Return True if the robot is close to the goal

    def rotate_point(self, point):
        # Function to rotate a point based on the starting angle of the robot
        rotation_matrix = np.array([[np.cos(self.starting_theta), -np.sin(self.starting_theta)],
                                    [np.sin(self.starting_theta), np.cos(self.starting_theta)]])
        rotated_point = np.dot(rotation_matrix, np.array(point))
        return rotated_point

def main(args=None):
    rclpy.init(args=args)
    node = TB4DriveSquare()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
